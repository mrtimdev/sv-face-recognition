"""Attendance authority — one connection per persistence worker.

Supports SQLite (local), PostgreSQL, and MySQL (remote) via the
``database`` abstraction layer.
"""
import json
import logging
import time
from datetime import datetime, timezone, timedelta

from .catalog import legacy_employee_id
from .database import connect, DatabaseError
from .models import SaveResult


def utc_iso(epoch):
    return datetime.fromtimestamp(epoch, timezone.utc).isoformat(timespec="milliseconds")


def parse_legacy_time(value):
    return datetime.fromisoformat(value).timestamp()


class AttendanceRepository:
    def __init__(self, config, employee_map=None, cooldown_sec=30.0, clock=time.time):
        self.config = config
        self.employee_map = employee_map or {}
        self.cooldown_sec, self.clock = cooldown_sec, clock
        self.connection = connect(config)
        try:
            if self.connection.backend == "sqlite":
                self.connection.execute("PRAGMA journal_mode=WAL")
                self.connection.execute("PRAGMA synchronous=FULL")
            self._migrate()
        except Exception:
            self.connection.close()
            raise

    def _employee_id(self, name):
        employee = self.employee_map.get(name)
        return employee.employee_id if employee else legacy_employee_id(name)

    def _migrate(self):
        conn = self.connection
        real = conn.real_type()
        # MySQL can only index and uniquely constrain sized text.
        key_text = "VARCHAR(255)" if conn.backend == "mysql" else "TEXT"
        with conn:
            conn.begin_immediate()

            if not conn.table_exists("attendance"):
                conn.execute(f"""CREATE TABLE IF NOT EXISTS attendance (
                    {conn.auto_id_column()}, name TEXT NOT NULL,
                    timestamp TEXT NOT NULL, status TEXT NOT NULL,
                    snapshot TEXT, duration {real},
                    employee_id {key_text}, event_id {key_text},
                    captured_at_epoch {real}, recorded_at_epoch {real})""")
            else:
                columns = conn.get_columns("attendance")
                for name, kind in (("employee_id", key_text), ("event_id", key_text),
                                   ("captured_at_epoch", real), ("recorded_at_epoch", real)):
                    if name not in columns:
                        conn.execute(f"ALTER TABLE attendance ADD COLUMN {name} {kind}")

            if conn.backend == "mysql":
                conn.execute("""CREATE TABLE IF NOT EXISTS attendance_cooldowns (
                    employee_id VARCHAR(255) PRIMARY KEY, last_capture_epoch DOUBLE NOT NULL)""")
                conn.execute("""CREATE TABLE IF NOT EXISTS attendance_outbox (
                    event_id VARCHAR(255) PRIMARY KEY, payload TEXT NOT NULL,
                    created_at TEXT NOT NULL, synced_at TEXT)""")
                conn.execute(f"""CREATE TABLE IF NOT EXISTS audit_log (
                    {conn.auto_id_column()},
                    timestamp TEXT NOT NULL, action TEXT NOT NULL,
                    detail TEXT, actor VARCHAR(255) DEFAULT 'system')""")
            else:
                conn.execute("""CREATE TABLE IF NOT EXISTS attendance_cooldowns (
                    employee_id TEXT PRIMARY KEY, last_capture_epoch REAL NOT NULL)""")
                conn.execute("""CREATE TABLE IF NOT EXISTS attendance_outbox (
                    event_id TEXT PRIMARY KEY, payload TEXT NOT NULL,
                    created_at TEXT NOT NULL, synced_at TEXT)""")
                conn.execute(f"""CREATE TABLE IF NOT EXISTS audit_log (
                    {conn.auto_id_column()},
                    timestamp TEXT NOT NULL, action TEXT NOT NULL,
                    detail TEXT, actor TEXT DEFAULT 'system')""")

            self._create_indexes(conn)
            self._backfill_legacy(conn)

    def _create_indexes(self, conn):
        if conn.backend == "mysql":
            for idx_sql in (
                "CREATE UNIQUE INDEX attendance_event_id ON attendance(event_id)",
                "CREATE INDEX attendance_recorded_time ON attendance(recorded_at_epoch)",
                "CREATE INDEX attendance_employee_time ON attendance(employee_id, recorded_at_epoch)",
            ):
                try:
                    conn.execute(idx_sql)
                except DatabaseError:
                    pass
        else:
            conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS attendance_event_id ON attendance(event_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS attendance_recorded_time ON attendance(recorded_at_epoch)")
            conn.execute("CREATE INDEX IF NOT EXISTS attendance_employee_time ON attendance(employee_id, recorded_at_epoch)")

    def _backfill_legacy(self, conn):
        for row in conn.execute(
                "SELECT id, name, timestamp FROM attendance WHERE employee_id IS NULL").fetchall():
            employee_id = self._employee_id(row["name"])
            try:
                timestamp = parse_legacy_time(row["timestamp"])
            except (ValueError, TypeError):
                timestamp = 0.0
            conn.execute(
                "UPDATE attendance SET employee_id=?, event_id=?, "
                "captured_at_epoch=?, recorded_at_epoch=? WHERE id=?",
                (employee_id, f"legacy-{row['id']}", timestamp, timestamp, row["id"]))

        remapped = {}
        for name, employee in self.employee_map.items():
            previous_id = legacy_employee_id(name)
            if previous_id == employee.employee_id:
                continue
            remapped[previous_id] = employee
            conn.execute("UPDATE attendance SET employee_id=? WHERE employee_id=?",
                         (employee.employee_id, previous_id))
            prior = conn.execute(
                "SELECT last_capture_epoch FROM attendance_cooldowns WHERE employee_id=?",
                (previous_id,)).fetchone()
            if prior:
                self._set_cooldown(employee.employee_id, prior[0])

        for row in (conn.execute(
                "SELECT event_id, payload FROM attendance_outbox WHERE synced_at IS NULL") if remapped else ()):
            payload = json.loads(row["payload"])
            employee = remapped.get(payload.get("employeeId"))
            if employee:
                payload["employeeId"] = employee.employee_id
                payload["employeeName"] = employee.name
                conn.execute("UPDATE attendance_outbox SET payload=? WHERE event_id=?",
                             (json.dumps(payload, ensure_ascii=False), row["event_id"]))

        if conn.backend == "sqlite":
            legacy = conn.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='capture_cooldown'"
            ).fetchone()
            if legacy:
                for row in conn.execute("SELECT name, last_capture FROM capture_cooldown"):
                    try:
                        epoch = parse_legacy_time(row["last_capture"])
                    except (ValueError, TypeError):
                        continue
                    self._set_cooldown(self._employee_id(row["name"]), epoch)

        for row in conn.execute(
                "SELECT employee_id, MAX(recorded_at_epoch) AS epoch "
                "FROM attendance GROUP BY employee_id").fetchall():
            self._set_cooldown(row["employee_id"], row["epoch"] or 0.0)

    def _set_cooldown(self, employee_id, epoch):
        self.connection.upsert_cooldown(employee_id, epoch)

    def load_cooldowns(self):
        return {row["employee_id"]: row["last_capture_epoch"] for row in
                self.connection.execute(
                    "SELECT employee_id, last_capture_epoch FROM attendance_cooldowns")}

    def verified_today(self):
        now = datetime.fromtimestamp(self.clock())
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
        row = self.connection.execute(
            "SELECT COUNT(DISTINCT employee_id) FROM attendance "
            "WHERE recorded_at_epoch >= ? AND recorded_at_epoch < ? AND status='KNOWN'",
            (start.timestamp(), end.timestamp())).fetchone()
        return {"date": start.date().isoformat(), "count": int(row[0])}

    def record(self, job, snapshots):
        from .enrollment import CATALOG_LOCK
        from .catalog import load_employee_map
        with CATALOG_LOCK:
            try:
                status_path = getattr(self.config, "employees_path", None)
                records = (load_employee_map(status_path)
                           if status_path is not None and status_path.exists() else self.employee_map)
                if any(e.employee_id == job.employee_id and not e.active for e in records.values()):
                    return SaveResult(job, "blocked", error="Inactive employee: attendance blocked")
            except (OSError, ValueError) as exc:
                return SaveResult(job, "error", error=f"Cannot verify employee status: {exc}")
            return self._record(job, snapshots)

    def _record(self, job, snapshots):
        conn, snapshot = self.connection, ""
        try:
            with conn:
                conn.begin_immediate()
                prior = conn.execute(
                    "SELECT * FROM attendance WHERE event_id=?",
                    (job.event_id,)).fetchone()
                if prior:
                    return SaveResult(job, "saved", prior["recorded_at_epoch"], prior["snapshot"])
                now = self.clock()
                last = conn.execute(
                    "SELECT last_capture_epoch FROM attendance_cooldowns WHERE employee_id=?",
                    (job.employee_id,)).fetchone()
                if last and now - last[0] < self.cooldown_sec:
                    return SaveResult(job, "duplicate", last[0])
                snapshot = snapshots.save(job)
                conn.execute(
                    "INSERT INTO attendance "
                    "(employee_id, event_id, name, timestamp, status, snapshot, duration, "
                    "captured_at_epoch, recorded_at_epoch) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (job.employee_id, job.event_id, job.employee_name, utc_iso(job.captured_at),
                     "KNOWN", snapshot, round(job.duration, 2), job.captured_at, now))
                self._set_cooldown(job.employee_id, now)
                payload = {"eventId": job.event_id, "employeeId": job.employee_id,
                           "employeeName": job.employee_name, "capturedAt": utc_iso(job.captured_at),
                           "recordedAt": utc_iso(now), "status": "KNOWN", "snapshotPath": snapshot,
                           "verifiedPresenceSeconds": round(job.duration, 2),
                           "matchDistance": job.match_distance, "liveScore": job.live_score}
                conn.execute(
                    "INSERT INTO attendance_outbox(event_id, payload, created_at) VALUES (?, ?, ?)",
                    (job.event_id, json.dumps(payload, ensure_ascii=False), utc_iso(now)))
            return SaveResult(job, "saved", now, snapshot)
        except Exception as exc:
            if snapshot:
                try:
                    snapshots.remove(snapshot)
                except OSError:
                    pass
            return SaveResult(job, "error", error=str(exc))

    def pending_outbox(self, limit=100):
        return [json.loads(row[0]) for row in self.connection.execute(
            "SELECT payload FROM attendance_outbox WHERE synced_at IS NULL "
            "ORDER BY created_at LIMIT ?", (limit,))]

    def mark_synced(self, event_id):
        with self.connection:
            self.connection.execute(
                "UPDATE attendance_outbox SET synced_at=? WHERE event_id=?",
                (utc_iso(self.clock()), event_id))

    def audit(self, action, detail="", actor="system"):
        try:
            self.connection.execute(
                "INSERT INTO audit_log(timestamp, action, detail, actor) VALUES (?, ?, ?, ?)",
                (utc_iso(self.clock()), action, detail, actor))
            self.connection.commit()
        except Exception:
            try:
                self.connection.rollback()
            except Exception:
                pass
            logging.debug("Audit log write failed", exc_info=True)

    def checkpoint(self):
        self.connection.checkpoint()

    def close(self):
        try:
            self.checkpoint()
        finally:
            self.connection.close()
