"""YuNet detection and SFace encoding run only on the recognition worker."""
import logging
import threading
import time

import cv2
import numpy as np

from .anti_spoof import AntiSpoofService
from .channels import LatestValue
from .enrollment import FACE_BACKEND_LOCK
from .face_backend import OpenCVFaceBackend
from .geometry import association_cost, iou
from .models import Detection, RecognitionResult
from .quality import FaceQuality, QualityResult


class RecognitionService:
    def __init__(self, config, catalog, backend=None, anti_spoof=None, quality=None):
        if backend is None:
            backend = OpenCVFaceBackend()
        self.backend, self.config = backend, config
        self.anti_spoof = AntiSpoofService() if anti_spoof is None else anti_spoof
        self.quality = FaceQuality(config) if quality is None else quality
        self.set_catalog(catalog)

    def set_catalog(self, catalog):
        """Use *catalog* from the next match on. Safe while the recognition worker is running."""
        indices = {}
        for index, employee in enumerate(catalog.employees):
            indices.setdefault(employee.employee_id, []).append(index)
        # One assignment, so a match in progress finishes with one consistent catalog.
        self._active = (catalog, indices)

    @property
    def catalog(self):
        return self._active[0]

    @property
    def employee_indices(self):
        return self._active[1]

    def match(self, encoding):
        catalog, indices_by_employee = self._active
        if len(catalog.encodings) == 0:
            return None, 1.0
        with FACE_BACKEND_LOCK:
            distances = self.backend.face_distance(catalog.encodings, encoding)
        ranked = sorted((float(np.min(distances[indices])), indices[0])
                        for indices in indices_by_employee.values())
        best, index = ranked[0]
        if best > self.config.face_tolerance:
            return None, best
        if len(ranked) > 1 and ranked[1][0] - best < self.config.identity_margin:
            return None, best
        return catalog.employees[index], best

    def process(self, request):
        started = time.monotonic()
        cfg, packet = self.config, request.packet
        height, width = packet.frame.shape[:2]
        small = cv2.resize(packet.frame, (max(1, round(width * cfg.detection_scale)),
                                          max(1, round(height * cfg.detection_scale))),
                           interpolation=cv2.INTER_AREA)
        rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
        with FACE_BACKEND_LOCK:
            boxes = self.backend.face_locations(rgb, model="yunet")
        sx, sy = width / small.shape[1], height / small.shape[0]
        full_boxes = [(t * sy, r * sx, b * sy, l * sx) for t, r, b, l in boxes]
        max_faces = getattr(cfg, "max_detect_faces", 5)
        if len(full_boxes) > max_faces:
            sized = sorted(enumerate(full_boxes),
                           key=lambda item: (item[1][2] - item[1][0]) * (item[1][1] - item[1][3]),
                           reverse=True)
            keep = {item[0] for item in sized[:max_faces]}
            boxes = [boxes[i] for i in sorted(keep)]
            full_boxes = [full_boxes[i] for i in sorted(keep)]
        full_rgb = None
        if isinstance(self.backend, OpenCVFaceBackend):
            full_rgb = cv2.cvtColor(packet.frame, cv2.COLOR_BGR2RGB)
            with FACE_BACKEND_LOCK:
                self.backend.promote(full_rgb, sx, sy)
        quality = {i: self.quality.inspect(packet.frame, box) for i, box in enumerate(full_boxes)}
        landmarks_map = {}
        # Pose/landmark quality applies even when expressions are not required.
        landmark_indices = [i for i in range(len(full_boxes)) if quality[i].ok]
        if landmark_indices and hasattr(self.backend, "face_landmarks"):
            if full_rgb is None:
                full_rgb = cv2.cvtColor(packet.frame, cv2.COLOR_BGR2RGB)
            landmark_boxes = [tuple(map(int, full_boxes[i])) for i in landmark_indices]
            try:
                with FACE_BACKEND_LOCK:
                    landmarks_list = self.backend.face_landmarks(full_rgb, landmark_boxes, model="large")
                landmarks_map = dict(zip(landmark_indices, landmarks_list))
            except Exception:
                logging.debug("Face landmark extraction failed", exc_info=True)
        for i in landmark_indices:
            quality[i] = self.quality.landmarks(quality[i], landmarks_map.get(i), full_boxes[i])
        hints, encode_indices, used_hints = {}, [], set()
        for index, box in enumerate(full_boxes):
            candidates = sorted((association_cost(box, hint.bounding_box), hint.track_id, hint)
                                for hint in request.hints)
            hint = None
            overlapping = any(index != j and iou(box, other) > 0.2
                              for j, other in enumerate(full_boxes))
            if (candidates and candidates[0][0] < 0.85 and not overlapping
                    and (len(candidates) == 1 or candidates[1][0] - candidates[0][0] > 0.2)):
                candidate = candidates[0][2]
                if candidate.track_id not in used_hints:
                    hint = candidate
                    used_hints.add(hint.track_id)
            hints[index] = hint
            due = (hint is None or not hint.stable
                   or packet.captured_at - hint.last_recognized >= cfg.stable_recheck_sec)
            if hint is not None and not hint.stable:
                due = packet.sequence - hint.last_encoded_sequence >= cfg.recognition_interval
            if due and quality[index].ok:
                encode_indices.append(index)
        encodings = []
        if encode_indices:
            encode_boxes = [(full_boxes if isinstance(self.backend, OpenCVFaceBackend) else boxes)[i] for i in encode_indices]
            with FACE_BACKEND_LOCK:
                encodings = self.backend.face_encodings(full_rgb if isinstance(self.backend, OpenCVFaceBackend) else rgb, encode_boxes)
        roi_map = {}
        for i in range(len(full_boxes)):
            t, r, b, l = full_boxes[i]
            t, b = int(max(0, t)), int(min(height, b))
            l, r = int(max(0, l)), int(min(width, r))
            if b - t >= 20 and r - l >= 20:
                roi_map[i] = packet.frame[t:b, l:r].copy()
        matches = {}
        for index, encoding in zip(encode_indices, encodings):
            matches[index] = self.match(encoding)
        detections = []
        for index, box in enumerate(full_boxes):
            employee, distance = matches.get(index, (None, None))
            hint = hints[index]
            lm = landmarks_map.get(index)
            roi = roi_map.get(index)
            if not quality[index].ok:
                detections.append(Detection(box, hint_id=hint.track_id if hint else None,
                    quality_ok=False, quality_prompt=quality[index].prompt,
                    quality_metrics=quality[index].metrics))
                continue
            # Run anti-spoof on candidate recognized employees or tracks evaluating presence.
            # Skip heavy dual-model inference on unknown faces to make unknown detection instantaneous.
            is_candidate = (employee is not None) or (hint is not None and getattr(hint, "employee_id", None))
            if hasattr(self.anti_spoof, "inspect"):
                inspection = self.anti_spoof.inspect(packet.frame, box)
                spoof_score, spoof_error = inspection["live_score"], inspection["error"]
                model_scores = tuple(model["live"] for model in inspection["models"])
            else:
                # Keep injected/custom PAD backends compatible with evaluate().
                spoof_score, spoof_error = self.anti_spoof.evaluate(packet.frame, box)
                model_scores = ()
            detections.append(Detection(box, employee, distance, index in encode_indices,
                                        hint.track_id if hint else None, lm, roi,
                                        spoof_score, spoof_error, model_scores,
                                        quality[index].ok, quality[index].prompt, quality[index].metrics))
        return RecognitionResult(packet, tuple(detections), time.monotonic() - started)


class RecognitionWorker:
    def __init__(self, service):
        self.service = service
        self.requests, self.results = LatestValue(), LatestValue()
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, name="recognition", daemon=True)

    def start(self):
        self.thread.start()

    def _run(self):
        while not self.stop_event.is_set():
            self.requests.ready.wait(0.1)
            request = self.requests.take()
            if request is None or self.stop_event.is_set():
                continue
            # Do not spend CPU encoding a request that has already expired in the mailbox.
            if time.monotonic() - request.packet.captured_at > self.service.config.max_result_age_sec:
                continue
            try:
                result = self.service.process(request)
            except Exception as exc:
                logging.exception("Face recognition failed")
                result = RecognitionResult(request.packet, (), 0, str(exc))
            self.results.put(result)

    def close(self):
        self.stop_event.set()
        self.requests.ready.set()
        if self.thread.ident is not None:
            self.thread.join(5)
        if self.thread.is_alive():
            logging.error("Recognition backend has not returned; shutting down its daemon thread with the process")
